
# ParseHub-like Scraping API (Node + Express + Playwright)

Headless scraping service exposing REST endpoints—no UI—covering 10 core features inspired by ParseHub:
1) JS-heavy websites (Playwright), 2) pagination, 3) login/auth flows, 4) complex steps (click/hover/scroll/wait),
5) flexible export (JSON/CSV/Excel), 6) API scheduling (cron), 7) proxy rotation, 8) data storage & optional S3 upload,
9) API key auth, 10) simple project configs (JSON).

## Quick start

```bash
# 1) Extract and install
npm install

# 2) Install browsers for Playwright
npx playwright install --with-deps

# 3) Configure environment
cp .env.example .env
# edit .env to set API_KEY, (optional) PROXIES and S3_*

# 4) Run
npm run dev
# Health check:
curl -H "Authorization: Bearer $API_KEY" http://localhost:8080/health
```

## Auth
All endpoints require `Authorization: Bearer <API_KEY>`.

## Project schema (JSON)

```json
{
  "name": "example products",
  "startUrl": "https://example.com/products",
  "waitForSelector": ".product-card",
  "selectorTimeout": 20000,
  "login": {
    "url": "https://example.com/login",
    "username": "user@example.com",
    "password": "secret",
    "usernameSelector": "#email",
    "passwordSelector": "#password",
    "submitSelector": "button[type=submit]"
  },
  "steps": [
    { "type": "scroll", "pixels": 1200 },
    { "type": "waitFor", "selector": ".product-card" }
  ],
  "selectors": {
    "item": ".product-card",
    "fields": [
      { "name": "title", "selector": ".title" },
      { "name": "price", "selector": ".price" },
      { "name": "url", "selector": "a", "attr": "href" },
      { "name": "image", "selector": "img", "attr": "src" }
    ]
  },
  "pagination": {
    "nextSelector": "a.next",
    "maxPages": 5
  }
}
```

## REST API

### Projects
- `GET /api/projects` — list projects  
- `POST /api/projects` — create project (body = project JSON above)  
- `GET /api/projects/:id` — get project  
- `PATCH /api/projects/:id` — update project  
- `DELETE /api/projects/:id` — delete project  

### Runs
- `GET /api/runs` — list runs  
- `POST /api/runs` — start a run (`{ "projectId": "<id>" }`)  
- `GET /api/runs/:id` — run status  
- `GET /api/runs/:id/artifact/:name` — download `data.json|data.csv|data.xlsx`  

### Schedules
- `GET /api/schedules` — list schedules  
- `POST /api/schedules` — create schedule `{ "projectId":"...", "cron":"0 * * * *", "enabled":true }`  
- `PATCH /api/schedules/:id` — update/enable/disable  
- `DELETE /api/schedules/:id` — delete  

> Cron format: `* * * * *` (min hour day month dayOfWeek). Example: `"0 */6 * * *"` = every 6 hours.

## Feature notes
- **Proxies/IP rotation**: Set `PROXIES` in `.env` as comma-separated proxy URLs. Each run uses the next proxy.
- **Login**: Provide `login` block if needed.
- **Dynamic sites**: Playwright waits for `networkidle` or `waitForSelector` as configured.
- **Complex flows**: `steps` array supports `click|hover|scroll|waitFor` in sequence.
- **Exports**: JSON/CSV/Excel saved under `data/<runId>/` and optionally uploaded to S3.
- **Rate limiting**: Basic limiter included; adjust per your needs.
- **Security**: API key middleware. Consider adding per-project secrets vaulting for production.

## Example curl

```bash
API=http://localhost:8080
KEY=change-me-please

# Create a project
curl -s -X POST "$API/api/projects"   -H "Authorization: Bearer $KEY" -H "Content-Type: application/json"   -d @- <<'JSON'
{
  "name": "HN front page",
  "startUrl": "https://news.ycombinator.com/",
  "waitForSelector": ".athing",
  "selectors": {
    "item": ".athing",
    "fields": [
      {"name": "rank", "selector": ".rank"},
      {"name": "title", "selector": ".titleline"},
      {"name": "link", "selector": ".titleline a", "attr": "href"}
    ]
  },
  "pagination": { "nextSelector": "a.morelink", "maxPages": 2 }
}
JSON

# Start a run
curl -s -X POST "$API/api/runs" -H "Authorization: Bearer $KEY"   -H "Content-Type: application/json" -d '{"projectId":"<paste-project-id>"}'

# Later: download artifacts
curl -OJ -H "Authorization: Bearer $KEY" "$API/api/runs/<runId>/artifact/data.csv"
```

## Deploy
- Any Node host works. Ensure Playwright browsers are installed at build/deploy time.
- For containers, use a Debian-based image and run `npx playwright install --with-deps` in the image.
