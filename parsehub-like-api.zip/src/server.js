
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { authMiddleware } from './utils/auth.js';
import projectsRouter from './routes/projects.js';
import runsRouter from './routes/runs.js';
import schedulesRouter from './routes/schedules.js';

dotenv.config();

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(cors());
app.use(helmet());
app.use(morgan('tiny'));

// Basic rate limiter
app.use(rateLimit({ windowMs: 60 * 1000, limit: 120 }));

// API key auth for all endpoints
app.use(authMiddleware);

// Routers
app.use('/api/projects', projectsRouter);
app.use('/api/runs', runsRouter);
app.use('/api/schedules', schedulesRouter);

// Health
app.get('/health', (req, res) => res.json({ ok: true }));

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`API listening on :${port}`));
