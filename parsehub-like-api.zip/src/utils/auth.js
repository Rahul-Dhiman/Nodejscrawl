
export function authMiddleware(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : header;
  const expected = process.env.API_KEY;
  if (!expected) return res.status(500).json({ error: 'Server misconfigured: API_KEY missing' });
  if (token !== expected) return res.status(401).json({ error: 'Unauthorized' });
  next();
}
