
let proxies = [];
let i = 0;

export function loadProxiesFromEnv() {
  const raw = process.env.PROXIES || '';
  proxies = raw.split(',').map(s => s.trim()).filter(Boolean);
}

export function nextProxy() {
  if (proxies.length === 0) return null;
  const proxy = proxies[i % proxies.length];
  i++;
  return proxy;
}
