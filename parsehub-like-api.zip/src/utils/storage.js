
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, '../../');

const fileFor = (name) => path.join(root, 'data', name + '.json');

function read(name) {
  const fp = fileFor(name);
  if (!fs.existsSync(fp)) return [];
  return JSON.parse(fs.readFileSync(fp, 'utf8'));
}

function write(name, value) {
  const fp = fileFor(name);
  fs.writeFileSync(fp, JSON.stringify(value, null, 2));
}

export const storage = { read, write };
