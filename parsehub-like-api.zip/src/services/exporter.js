
import { Parser } from 'json2csv';
import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';

export async function toJSONFile(data, outPath) {
  fs.writeFileSync(outPath, JSON.stringify(data, null, 2));
}

export async function toCSVFile(data, outPath) {
  const parser = new Parser();
  const csv = parser.parse(data);
  fs.writeFileSync(outPath, csv);
}

export async function toExcelFile(data, outPath, sheetName = 'data') {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(sheetName);
  if (data.length) {
    ws.columns = Object.keys(data[0]).map(k => ({ header: k, key: k }));
    data.forEach(row => ws.addRow(row));
  }
  await wb.xlsx.writeFile(outPath);
}
