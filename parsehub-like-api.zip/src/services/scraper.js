
/**
 * Core scraper using Playwright to support JS-heavy sites, login, pagination, and complex steps.
 * Projects are stored as JSON configs describing selectors and steps.
 */
import fs from 'fs';
import path from 'path';
import { v4 as uuid } from 'uuid';
import { chromium } from 'playwright';
import { storage } from '../utils/storage.js';
import { nextProxy, loadProxiesFromEnv } from '../utils/proxyPool.js';
import { toJSONFile, toCSVFile, toExcelFile } from './exporter.js';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

loadProxiesFromEnv();

const root = path.resolve(process.cwd());
const runsDir = path.join(root, 'data');

const s3 = process.env.S3_BUCKET ? new S3Client({ region: process.env.AWS_REGION || 'us-east-1' }) : null;

function getProjects() { return storage.read('projects'); }
function saveProjects(p) { storage.write('projects', p); }
function getRuns() { return storage.read('runs'); }
function saveRuns(r) { storage.write('runs', r); }

export function createProject(project) {
  const projects = getProjects();
  const id = uuid();
  const createdAt = new Date().toISOString();
  const record = { id, createdAt, ...project };
  projects.push(record);
  saveProjects(projects);
  return record;
}

export function listProjects() { return getProjects(); }

export function getProject(id) {
  return getProjects().find(p => p.id === id);
}

export function updateProject(id, patch) {
  const projects = getProjects();
  const idx = projects.findIndex(p => p.id === id);
  if (idx === -1) return null;
  projects[idx] = { ...projects[idx], ...patch, updatedAt: new Date().toISOString() };
  saveProjects(projects);
  return projects[idx];
}

export function removeProject(id) {
  const projects = getProjects().filter(p => p.id !== id);
  saveProjects(projects);
}

export async function startRun(projectId, { trigger = 'api', options = {} } = {}) {
  const proj = getProject(projectId);
  if (!proj) throw new Error('Project not found');
  const runId = uuid();
  const startedAt = new Date().toISOString();
  const run = { id: runId, projectId, status: 'running', startedAt, trigger };
  const runs = getRuns();
  runs.push(run);
  saveRuns(runs);

  try {
    const proxy = nextProxy();
    const browser = await chromium.launch({
      headless: true,
      proxy: proxy ? { server: proxy } : undefined,
    });
    const context = await browser.newContext();
    const page = await context.newPage();

    // LOGIN (optional)
    if (proj.login) {
      const { url, username, password, usernameSelector, passwordSelector, submitSelector } = proj.login;
      await page.goto(url, { waitUntil: 'domcontentloaded' });
      if (usernameSelector) await page.fill(usernameSelector, username);
      if (passwordSelector) await page.fill(passwordSelector, password);
      if (submitSelector) await page.click(submitSelector);
      await page.waitForLoadState('networkidle');
    }

    // Navigate
    await page.goto(proj.startUrl, { waitUntil: 'domcontentloaded' });
    if (proj.waitForSelector) {
      await page.waitForSelector(proj.waitForSelector, { timeout: proj.selectorTimeout || 15000 });
    } else {
      await page.waitForLoadState('networkidle');
    }

    // Execute steps (hover, click, scroll, etc.)
    if (Array.isArray(proj.steps)) {
      for (const step of proj.steps) {
        if (step.type === 'click') await page.click(step.selector);
        if (step.type === 'hover') await page.hover(step.selector);
        if (step.type === 'scroll') await page.mouse.wheel(0, step.pixels || 1000);
        if (step.type === 'waitFor') await page.waitForSelector(step.selector, { timeout: step.timeout || 15000 });
      }
    }

    // Pagination
    const maxPages = proj.pagination?.maxPages || 1;
    const nextSelector = proj.pagination?.nextSelector;
    let data = [];
    for (let i = 0; i < maxPages; i++) {
      // Extract data for this page
      const rows = await page.$$eval(proj.selectors.item, (nodes, fields) => {
        return nodes.map(node => {
          const rec = {};
          for (const field of fields) {
            const el = field.selector ? node.querySelector(field.selector) : node;
            let val = null;
            if (!el) { rec[field.name] = null; continue; }
            if (field.attr) val = el.getAttribute(field.attr);
            else val = el.textContent?.trim();
            rec[field.name] = val;
          }
          return rec;
        });
      }, proj.selectors.fields);
      data.push(...rows);

      // go next if possible
      if (i < maxPages - 1 && nextSelector) {
        const hasNext = await page.$(nextSelector);
        if (!hasNext) break;
        await Promise.all([
          page.click(nextSelector),
          page.waitForLoadState('networkidle')
        ]);
      }
    }

    // Persist artifacts
    const dir = path.join(runsDir, runId);
    fs.mkdirSync(dir, { recursive: true });
    const jsonPath = path.join(dir, 'data.json');
    const csvPath = path.join(dir, 'data.csv');
    const xlsxPath = path.join(dir, 'data.xlsx');

    await toJSONFile(data, jsonPath);
    await toCSVFile(data, csvPath);
    await toExcelFile(data, xlsxPath);

    // Optional S3 upload
    if (s3) {
      const bucket = process.env.S3_BUCKET;
      const prefix = process.env.S3_PREFIX || 'parsehub-like';
      for (const fp of [jsonPath, csvPath, xlsxPath]) {
        const Body = fs.readFileSync(fp);
        const Key = `${prefix}/${runId}/${path.basename(fp)}`;
        await s3.send(new PutObjectCommand({ Bucket: bucket, Key, Body }));
      }
    }

    // Finish
    const runs2 = getRuns();
    const idx = runs2.findIndex(r => r.id === runId);
    runs2[idx] = { ...runs2[idx], status: 'succeeded', finishedAt: new Date().toISOString(), rows: data.length, artifactsDir: dir };
    saveRuns(runs2);

    await browser.close();
    return runs2[idx];
  } catch (err) {
    const runs2 = getRuns();
    const idx = runs2.findIndex(r => r.id === runId);
    runs2[idx] = { ...runs2[idx], status: 'failed', error: String(err), finishedAt: new Date().toISOString() };
    saveRuns(runs2);
    return runs2[idx];
  }
}

export function listRuns() { return getRuns(); }
export function getRun(id) { return getRuns().find(r => r.id === id); }
