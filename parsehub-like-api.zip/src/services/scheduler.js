
import cron from 'node-cron';
import { storage } from '../utils/storage.js';
import { startRun } from './scraper.js';

const jobs = new Map();

export function loadSchedules() {
  const schedules = storage.read('schedules');
  schedules.forEach(schedule => {
    if (schedule.enabled) scheduleJob(schedule);
  });
}

export function scheduleJob(schedule) {
  const task = cron.schedule(schedule.cron, async () => {
    await startRun(schedule.projectId, { trigger: 'schedule', options: schedule.options || {} });
  }, { scheduled: true });
  jobs.set(schedule.id, task);
}

export function cancelJob(id) {
  const task = jobs.get(id);
  if (task) {
    task.stop();
    jobs.delete(id);
  }
}
