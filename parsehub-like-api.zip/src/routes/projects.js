
import { Router } from 'express';
import { v4 as uuid } from 'uuid';
import { storage } from '../utils/storage.js';
import { createProject, listProjects, getProject, updateProject, removeProject } from '../services/scraper.js';

const router = Router();

router.get('/', (req, res) => {
  res.json(listProjects());
});

router.post('/', (req, res) => {
  const project = req.body;
  if (!project?.name || !project?.startUrl || !project?.selectors) {
    return res.status(400).json({ error: 'name, startUrl, selectors are required' });
  }
  const created = createProject(project);
  res.status(201).json(created);
});

router.get('/:id', (req, res) => {
  const proj = getProject(req.params.id);
  if (!proj) return res.status(404).json({ error: 'Not found' });
  res.json(proj);
});

router.patch('/:id', (req, res) => {
  const updated = updateProject(req.params.id, req.body || {});
  if (!updated) return res.status(404).json({ error: 'Not found' });
  res.json(updated);
});

router.delete('/:id', (req, res) => {
  removeProject(req.params.id);
  res.status(204).end();
});

export default router;
