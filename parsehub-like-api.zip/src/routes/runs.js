
import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { startRun, listRuns, getRun } from '../services/scraper.js';

const router = Router();

router.get('/', (req, res) => {
  res.json(listRuns());
});

router.post('/', async (req, res) => {
  const { projectId, options } = req.body || {};
  if (!projectId) return res.status(400).json({ error: 'projectId is required' });
  const run = await startRun(projectId, { trigger: 'api', options });
  res.status(201).json(run);
});

router.get('/:id', (req, res) => {
  const run = getRun(req.params.id);
  if (!run) return res.status(404).json({ error: 'Not found' });
  res.json(run);
});

// Download artifacts
router.get('/:id/artifact/:name', (req, res) => {
  const run = getRun(req.params.id);
  if (!run || !run.artifactsDir) return res.status(404).json({ error: 'Not found' });
  const fp = path.join(run.artifactsDir, req.params.name);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'File not found' });
  res.download(fp);
});

export default router;
