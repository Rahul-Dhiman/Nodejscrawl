
import { Router } from 'express';
import { v4 as uuid } from 'uuid';
import { storage } from '../utils/storage.js';
import { scheduleJob, cancelJob } from '../services/scheduler.js';

const router = Router();

function list() { return storage.read('schedules'); }
function save(all) { storage.write('schedules', all); }

router.get('/', (req, res) => {
  res.json(list());
});

router.post('/', (req, res) => {
  const { projectId, cron, enabled = true, options } = req.body || {};
  if (!projectId || !cron) return res.status(400).json({ error: 'projectId and cron are required' });
  const rec = { id: uuid(), projectId, cron, enabled, options };
  const all = list(); all.push(rec); save(all);
  if (enabled) scheduleJob(rec);
  res.status(201).json(rec);
});

router.patch('/:id', (req, res) => {
  const all = list();
  const idx = all.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const before = all[idx];
  all[idx] = { ...before, ...req.body };
  save(all);
  cancelJob(before.id);
  if (all[idx].enabled) scheduleJob(all[idx]);
  res.json(all[idx]);
});

router.delete('/:id', (req, res) => {
  const all = list().filter(s => s.id !== req.params.id);
  save(all);
  cancelJob(req.params.id);
  res.status(204).end();
});

export default router;
