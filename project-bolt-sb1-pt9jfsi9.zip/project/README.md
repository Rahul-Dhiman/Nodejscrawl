# Web Crawler API

A high-performance web crawling and scraping API built with Node.js and Express. Features dual engines (HTTP + Playwright), intelligent crawling strategies, and comprehensive data extraction capabilities.

## Features

- **Dual Engine Support**: HTTP client (undici/got) with optional Playwright renderer
- **Smart Crawling**: Sitemap parsing, BFS spider crawling, robots.txt compliance
- **Advanced Extraction**: Text extraction, SPA support, JSON discovery
- **Authentication**: Form, Bearer, Basic, and Cookie authentication
- **Data Processing**: Boilerplate deduplication, NDJSON output, checkpointing
- **Performance**: Configurable concurrency, rate limiting, exponential backoff
- **Reliability**: Resume functionality, comprehensive error handling

## Installation

```bash
npm install
```

For Playwright support (optional):
```bash
npx playwright install --with-deps
```

## Configuration

Copy `.env.example` to `.env` and configure:

```bash
PORT=8080
API_KEY=change-me
ENGINE=http                    # http or renderer
MAX_CONCURRENCY=8              # Global concurrency limit
PER_HOST_CONCURRENCY=2         # Per-host concurrency limit
PER_HOST_DELAY_MS=500          # Delay between requests to same host
RETRIES=3                      # Retry attempts for failed requests
TIMEOUT_MS=20000               # Request timeout
USER_AGENT=MyCrawler/1.0       # User agent string
RESPECT_ROBOTS=true            # Respect robots.txt
```

## Usage

Start the server:
```bash
npm run dev          # Development mode
npm start            # Production mode
```

### API Endpoints

#### Start Crawl
```bash
curl -X POST http://localhost:8080/api/crawl/start \
  -H "Authorization: Bearer change-me" \
  -H "Content-Type: application/json" \
  -d '{
    "engine": "http",
    "mode": "auto",
    "seeds": ["https://example.com"],
    "maxPages": 1000,
    "include": ["^https://example\\.com"],
    "exclude": ["\\.(jpg|png|pdf)$"],
    "sameHost": true,
    "onlyBodyText": true
  }'
```

#### Check Status
```bash
curl -H "Authorization: Bearer change-me" \
  http://localhost:8080/api/crawl/status/[RUN_ID]
```

#### Download Results
```bash
curl -H "Authorization: Bearer change-me" \
  http://localhost:8080/api/crawl/download/[RUN_ID] \
  -o crawl-results.ndjson
```

#### Stop Crawl
```bash
curl -X POST -H "Authorization: Bearer change-me" \
  http://localhost:8080/api/crawl/stop/[RUN_ID]
```

#### Clean/Deduplicate
```bash
curl -X POST -H "Authorization: Bearer change-me" \
  http://localhost:8080/api/index/clean/[RUN_ID]
```

### Request Body Options

#### Basic Configuration
- `engine`: `"http"` or `"renderer"` - Crawling engine
- `mode`: `"auto"`, `"sitemap"`, or `"spider"` - Crawling strategy
- `seeds`: Array of starting URLs
- `sitemapUrl`: URL to sitemap.xml (for sitemap mode)
- `maxPages`: Maximum pages to crawl (default: 20000)
- `sameHost`: Only crawl same host as seeds (default: true)
- `onlyBodyText`: Extract only body text content (default: true)

#### URL Filtering
- `include`: Array of regex patterns for URLs to include
- `exclude`: Array of regex patterns for URLs to exclude

#### Authentication
```json
{
  "login": {
    "type": "form",
    "form": {
      "loginUrl": "https://example.com/login",
      "username": "user@example.com",
      "password": "password",
      "usernameField": "email",
      "passwordField": "password",
      "csrf": {
        "tokenFrom": "selector",
        "selector": "input[name=_csrf]"
      }
    }
  }
}
```

#### SPA Support
```json
{
  "spa": {
    "jsonDiscovery": true,
    "apiBaseHints": ["/api", "/_next/data/"],
    "extractEmbeddedState": true
  }
}
```

### Response Format

Each crawled page is output in NDJSON format:

```json
{
  "url": "https://example.com/page",
  "status": 200,
  "title": "Page Title",
  "description": "Meta description",
  "text": "Extracted text content...",
  "html": "Full HTML content...",
  "lang": "en",
  "framework": ["nextjs", "react"],
  "contentType": "text/html",
  "contentLength": 12345,
  "sha1": "abc123...",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "wordCount": 500,
  "charCount": 3000,
  "spaData": {
    "nextData": {...},
    "discoveredApis": [...]
  }
}
```

## Architecture

```
src/
├── server.js              # Express server setup
├── routes/
│   ├── crawl.js          # Crawl endpoints
│   └── index.js          # Index/dedup endpoints
├── services/
│   ├── crawler.js        # Main crawler orchestration
│   ├── sitemap.js        # Sitemap parsing
│   ├── spider.js         # Link extraction & BFS crawling
│   ├── extract.js        # Content extraction (HTTP/Playwright)
│   ├── auth.js           # Authentication handling
│   ├── dedupe.js         # Deduplication service
│   └── robots.js         # Robots.txt compliance
└── utils/
    ├── url.js            # URL utilities
    ├── stream.js         # NDJSON streaming
    ├── hash.js           # Hashing utilities
    ├── log.js            # Logging setup
    └── frameworks.js     # SPA framework detection
```

## Advanced Features

### Checkpointing & Resume
Crawls are automatically checkpointed every 30 seconds. Resume a crawl:

```json
{
  "resumeRunId": "previous-run-uuid",
  "seeds": ["https://example.com"]
}
```

### Boilerplate Deduplication
Automatically identifies and removes recurring content patterns across documents. Configurable with `batchSizeForDedupe`.

### SPA Support
- Extracts embedded JSON state (`__NEXT_DATA__`, `__NUXT__`, etc.)
- Auto-discovers API endpoints
- Supports JSON-LD extraction

### Rate Limiting & Compliance
- Respects `robots.txt` and crawl delays
- Per-host concurrency limits
- Exponential backoff on errors
- Configurable request timeouts

## Health Check

```bash
curl http://localhost:8080/health
```

## Error Handling

The API provides comprehensive error handling with structured logging. Check logs for detailed error information and debugging.

## Performance Tuning

Adjust these environment variables based on your needs:
- Increase `MAX_CONCURRENCY` for faster crawling (more CPU/memory usage)
- Decrease `PER_HOST_DELAY_MS` for faster crawling (higher load on target sites)
- Adjust `TIMEOUT_MS` based on target site response times
- Use `renderer` engine only when necessary (much slower but handles JS)

## License

MIT