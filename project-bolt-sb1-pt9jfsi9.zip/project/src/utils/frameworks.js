import * as cheerio from 'cheerio';

export function detectFramework(html) {
  const frameworks = [];
  
  // Check for Next.js
  if (html.includes('__NEXT_DATA__') || html.includes('_next/static')) {
    frameworks.push('nextjs');
  }
  
  // Check for Nuxt
  if (html.includes('__NUXT__') || html.includes('_nuxt/')) {
    frameworks.push('nuxt');
  }
  
  // Check for React
  if (html.includes('react') || html.includes('ReactDOM')) {
    frameworks.push('react');
  }
  
  // Check for Vue
  if (html.includes('Vue.js') || html.includes('vue.runtime')) {
    frameworks.push('vue');
  }
  
  // Check for Angular
  if (html.includes('ng-version') || html.includes('angular')) {
    frameworks.push('angular');
  }
  
  // Check for Gatsby
  if (html.includes('___gatsby') || html.includes('gatsby-')) {
    frameworks.push('gatsby');
  }
  
  return frameworks;
}

export function extractSpaData(html, url, spaConfig = {}) {
  const $ = cheerio.load(html);
  const spaData = {};
  
  try {
    // Extract Next.js data
    const nextDataScript = $('script#__NEXT_DATA__').html();
    if (nextDataScript) {
      try {
        const nextData = JSON.parse(nextDataScript);
        spaData.nextData = nextData;
      } catch (e) {
        // Ignore parsing errors
      }
    }
    
    // Extract Nuxt data
    const nuxtScript = $('script').filter((_, el) => {
      const content = $(el).html() || '';
      return content.includes('window.__NUXT__');
    }).first().html();
    
    if (nuxtScript) {
      try {
        // Extract the JSON data from window.__NUXT__
        const match = nuxtScript.match(/window\.__NUXT__\s*=\s*({.*?});/s);
        if (match) {
          const nuxtData = JSON.parse(match[1]);
          spaData.nuxtData = nuxtData;
        }
      } catch (e) {
        // Ignore parsing errors
      }
    }
    
    // Extract Apollo/GraphQL state
    $('script').each((_, el) => {
      const content = $(el).html() || '';
      if (content.includes('__APOLLO_STATE__') || content.includes('apollo-cache')) {
        try {
          const match = content.match(/__APOLLO_STATE__\s*=\s*({.*?});/s);
          if (match) {
            spaData.apolloState = JSON.parse(match[1]);
          }
        } catch (e) {
          // Ignore parsing errors
        }
      }
    });
    
    // Auto-discover API endpoints if enabled
    if (spaConfig.jsonDiscovery && spaConfig.apiBaseHints) {
      const apiEndpoints = new Set();
      
      // Look for API calls in script tags
      $('script').each((_, el) => {
        const content = $(el).html() || '';
        
        for (const hint of spaConfig.apiBaseHints) {
          const regex = new RegExp(`["'\`]([^"'\`]*${hint.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[^"'\`]*)["'\`]`, 'gi');
          let match;
          while ((match = regex.exec(content)) !== null) {
            const endpoint = match[1];
            if (endpoint.startsWith('http') || endpoint.startsWith('/')) {
              apiEndpoints.add(endpoint);
            }
          }
        }
      });
      
      if (apiEndpoints.size > 0) {
        spaData.discoveredApis = Array.from(apiEndpoints).slice(0, 20); // Limit to prevent spam
      }
    }
    
    // Extract embedded JSON-LD
    $('script[type="application/ld+json"]').each((_, el) => {
      try {
        const jsonLd = JSON.parse($(el).html() || '{}');
        if (!spaData.jsonLd) spaData.jsonLd = [];
        spaData.jsonLd.push(jsonLd);
      } catch (e) {
        // Ignore parsing errors
      }
    });
    
  } catch (error) {
    // Return partial data if available
  }
  
  return spaData;
}

export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Detect if page is likely an SPA
export function isSpaPage(html) {
  const indicators = [
    '__NEXT_DATA__',
    '__NUXT__',
    'react-root',
    'vue-app',
    'ng-version',
    'data-react-',
    'data-vue-',
    '_next/static',
    '_nuxt/'
  ];
  
  return indicators.some(indicator => html.includes(indicator));
}