import { URL } from 'url';

export function isValidUrl(string) {
  try {
    const url = new URL(string);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

export function normalizeUrl(url) {
  try {
    const urlObj = new URL(url);
    
    // Remove common tracking parameters
    const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid'];
    trackingParams.forEach(param => {
      urlObj.searchParams.delete(param);
    });
    
    // Remove fragment
    urlObj.hash = '';
    
    // Remove trailing slash for paths (but not for root)
    if (urlObj.pathname !== '/' && urlObj.pathname.endsWith('/')) {
      urlObj.pathname = urlObj.pathname.slice(0, -1);
    }
    
    return urlObj.toString();
  } catch {
    return url;
  }
}

export function resolveUrl(url, base) {
  try {
    return new URL(url, base).toString();
  } catch {
    return null;
  }
}

export function isSameHost(url1, url2) {
  try {
    const host1 = new URL(url1).hostname;
    const host2 = typeof url2 === 'string' ? new URL(url2).hostname : url2;
    return host1 === host2;
  } catch {
    return false;
  }
}

export function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}

export function getPathDepth(url) {
  try {
    const path = new URL(url).pathname;
    return path.split('/').filter(segment => segment.length > 0).length;
  } catch {
    return 0;
  }
}