import crypto from 'crypto';

export function generateHash(content, algorithm = 'sha1') {
  return crypto
    .createHash(algorithm)
    .update(content, 'utf8')
    .digest('hex');
}

export function generateMd5(content) {
  return generateHash(content, 'md5');
}

export function generateSha256(content) {
  return generateHash(content, 'sha256');
}

// Generate hash from multiple fields
export function generateCompositeHash(...fields) {
  const combined = fields.filter(f => f != null).join('||');
  return generateHash(combined);
}

// Generate URL-safe hash
export function generateUrlSafeHash(content) {
  return generateHash(content)
    .replace(/[^a-zA-Z0-9]/g, '')
    .substring(0, 16);
}