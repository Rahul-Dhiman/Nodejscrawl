import fs from 'fs';
import { Transform } from 'stream';
import { createLogger } from './log.js';

const logger = createLogger('stream');

export function createNdjsonWriter(filePath) {
  const writeStream = fs.createWriteStream(filePath, { flags: 'a' });
  
  return {
    write(record) {
      return new Promise((resolve, reject) => {
        const line = JSON.stringify(record) + '\n';
        writeStream.write(line, 'utf8', (error) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });
    },
    
    end() {
      return new Promise((resolve, reject) => {
        writeStream.end((error) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });
    }
  };
}

export function createNdjsonReader(filePath) {
  const readStream = fs.createReadStream(filePath, { encoding: 'utf8' });
  let buffer = '';
  
  const transform = new Transform({
    objectMode: true,
    transform(chunk, encoding, callback) {
      buffer += chunk;
      const lines = buffer.split('\n');
      
      // Keep the last incomplete line in buffer
      buffer = lines.pop();
      
      for (const line of lines) {
        if (line.trim()) {
          try {
            const record = JSON.parse(line);
            this.push(record);
          } catch (error) {
            logger.warn({ error, line: line.substring(0, 100) }, 'Failed to parse NDJSON line');
          }
        }
      }
      
      callback();
    },
    
    flush(callback) {
      if (buffer.trim()) {
        try {
          const record = JSON.parse(buffer);
          this.push(record);
        } catch (error) {
          logger.warn({ error, line: buffer.substring(0, 100) }, 'Failed to parse final NDJSON line');
        }
      }
      callback();
    }
  });
  
  return readStream.pipe(transform);
}

export class BatchProcessor extends Transform {
  constructor(batchSize = 1000, processBatch = async (batch) => batch) {
    super({ objectMode: true });
    this.batchSize = batchSize;
    this.processBatch = processBatch;
    this.batch = [];
  }
  
  async _transform(chunk, encoding, callback) {
    this.batch.push(chunk);
    
    if (this.batch.length >= this.batchSize) {
      await this.flushBatch();
    }
    
    callback();
  }
  
  async _flush(callback) {
    if (this.batch.length > 0) {
      await this.flushBatch();
    }
    callback();
  }
  
  async flushBatch() {
    if (this.batch.length === 0) return;
    
    try {
      const processedBatch = await this.processBatch([...this.batch]);
      for (const item of processedBatch) {
        this.push(item);
      }
    } catch (error) {
      logger.error({ error }, 'Batch processing failed');
    }
    
    this.batch = [];
  }
}