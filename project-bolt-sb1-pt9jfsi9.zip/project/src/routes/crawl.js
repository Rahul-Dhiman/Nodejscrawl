import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs/promises';
import path from 'path';
import CrawlerService from '../services/crawler.js';
import { createLogger } from '../utils/log.js';

const router = express.Router();
const logger = createLogger('crawl-routes');

// Active crawl runs
const activeRuns = new Map();

// Start crawl
router.post('/start', async (req, res) => {
  try {
    const runId = uuidv4();
    const config = {
      runId,
      engine: req.body.engine || process.env.ENGINE || 'http',
      mode: req.body.mode || 'auto',
      sitemapUrl: req.body.sitemapUrl,
      seeds: req.body.seeds || [],
      include: req.body.include || [],
      exclude: req.body.exclude || [],
      sameHost: req.body.sameHost !== false,
      maxPages: req.body.maxPages || 20000,
      onlyBodyText: req.body.onlyBodyText !== false,
      batchSizeForDedupe: req.body.batchSizeForDedupe || 1000,
      login: req.body.login,
      spa: req.body.spa,
      resumeRunId: req.body.resumeRunId
    };

    // Validate required fields
    if (!config.sitemapUrl && (!config.seeds || config.seeds.length === 0)) {
      return res.status(400).json({
        error: 'Either sitemapUrl or seeds must be provided'
      });
    }

    logger.info({ runId, config }, 'Starting new crawl');

    const crawler = new CrawlerService(config);
    activeRuns.set(runId, crawler);

    // Start crawling in background
    crawler.start().catch(error => {
      logger.error({ runId, error }, 'Crawl failed');
      activeRuns.delete(runId);
    });

    res.json({
      runId,
      status: 'started',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error({ error }, 'Failed to start crawl');
    res.status(500).json({ error: 'Failed to start crawl' });
  }
});

// Get crawl status
router.get('/status/:runId', async (req, res) => {
  try {
    const { runId } = req.params;
    const crawler = activeRuns.get(runId);

    if (!crawler) {
      // Check if there's a completed run file
      try {
        const statsPath = path.join('data', `run-${runId}-stats.json`);
        const stats = JSON.parse(await fs.readFile(statsPath, 'utf8'));
        return res.json(stats);
      } catch {
        return res.status(404).json({ error: 'Run not found' });
      }
    }

    const status = crawler.getStatus();
    res.json(status);
  } catch (error) {
    logger.error({ error }, 'Failed to get status');
    res.status(500).json({ error: 'Failed to get status' });
  }
});

// Download crawl results
router.get('/download/:runId', async (req, res) => {
  try {
    const { runId } = req.params;
    const filePath = path.join('data', `run-${runId}.ndjson`);

    try {
      await fs.access(filePath);
    } catch {
      return res.status(404).json({ error: 'Results not found' });
    }

    res.setHeader('Content-Type', 'application/x-ndjson');
    res.setHeader('Content-Disposition', `attachment; filename="crawl-${runId}.ndjson"`);

    const fileStream = await fs.open(filePath, 'r');
    const readableStream = fileStream.createReadStream();
    
    readableStream.pipe(res);
    
    readableStream.on('end', () => {
      fileStream.close();
    });
    
    readableStream.on('error', (error) => {
      logger.error({ error }, 'Stream error');
      fileStream.close();
      if (!res.headersSent) {
        res.status(500).json({ error: 'Failed to stream results' });
      }
    });
  } catch (error) {
    logger.error({ error }, 'Failed to download results');
    res.status(500).json({ error: 'Failed to download results' });
  }
});

// Stop crawl
router.post('/stop/:runId', async (req, res) => {
  try {
    const { runId } = req.params;
    const crawler = activeRuns.get(runId);

    if (!crawler) {
      return res.status(404).json({ error: 'Run not found' });
    }

    await crawler.stop();
    activeRuns.delete(runId);

    res.json({
      runId,
      status: 'stopped',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error({ error }, 'Failed to stop crawl');
    res.status(500).json({ error: 'Failed to stop crawl' });
  }
});

export default router;