import express from 'express';
import DedupeService from '../services/dedupe.js';
import { createLogger } from '../utils/log.js';

const router = express.Router();
const logger = createLogger('index-routes');

// Clean/dedupe index
router.post('/clean/:runId', async (req, res) => {
  try {
    const { runId } = req.params;
    const batchSize = req.body.batchSize || 1000;

    logger.info({ runId, batchSize }, 'Starting dedupe process');

    const dedupeService = new DedupeService();
    const result = await dedupeService.deduplicateRun(runId, batchSize);

    res.json({
      runId,
      status: 'completed',
      ...result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error({ error }, 'Failed to clean index');
    res.status(500).json({ error: 'Failed to clean index' });
  }
});

export default router;