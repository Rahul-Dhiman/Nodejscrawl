import * as cheerio from 'cheerio';
import { createLogger } from '../utils/log.js';
import { isValidUrl, normalizeUrl, resolveUrl } from '../utils/url.js';

export default class SpiderService {
  constructor() {
    this.logger = createLogger('spider');
  }

  extractLinks(html, baseUrl) {
    if (!html) return [];

    try {
      const $ = cheerio.load(html);
      const links = new Set();

      // Extract from various elements
      $('a[href]').each((_, el) => {
        const href = $(el).attr('href');
        if (href) {
          const resolvedUrl = resolveUrl(href, baseUrl);
          if (resolvedUrl && isValidUrl(resolvedUrl)) {
            links.add(normalizeUrl(resolvedUrl));
          }
        }
      });

      // Extract from canonical links
      $('link[rel="canonical"][href]').each((_, el) => {
        const href = $(el).attr('href');
        if (href) {
          const resolvedUrl = resolveUrl(href, baseUrl);
          if (resolvedUrl && isValidUrl(resolvedUrl)) {
            links.add(normalizeUrl(resolvedUrl));
          }
        }
      });

      // Extract from sitemap references
      $('link[rel="sitemap"][href]').each((_, el) => {
        const href = $(el).attr('href');
        if (href) {
          const resolvedUrl = resolveUrl(href, baseUrl);
          if (resolvedUrl && isValidUrl(resolvedUrl)) {
            links.add(normalizeUrl(resolvedUrl));
          }
        }
      });

      const result = Array.from(links);
      this.logger.debug({ baseUrl, linkCount: result.length }, 'Extracted links');
      
      return result;
    } catch (error) {
      this.logger.error({ error, baseUrl }, 'Failed to extract links');
      return [];
    }
  }

  // BFS crawling strategy
  async crawlBreadthFirst(seedUrls, options = {}) {
    const {
      maxDepth = 3,
      maxPages = 10000,
      onVisit = () => {},
      shouldVisit = () => true
    } = options;

    const visited = new Set();
    const queue = seedUrls.map(url => ({ url: normalizeUrl(url), depth: 0 }));
    const results = [];

    while (queue.length > 0 && results.length < maxPages) {
      const { url, depth } = queue.shift();

      if (visited.has(url) || depth > maxDepth) {
        continue;
      }

      if (!shouldVisit(url)) {
        continue;
      }

      visited.add(url);

      try {
        const result = await onVisit(url, depth);
        if (result) {
          results.push(result);
          
          // Extract links for next level
          if (depth < maxDepth && result.html) {
            const links = this.extractLinks(result.html, url);
            for (const link of links.slice(0, 20)) { // Limit per page
              if (!visited.has(link)) {
                queue.push({ url: link, depth: depth + 1 });
              }
            }
          }
        }
      } catch (error) {
        this.logger.error({ error, url }, 'Failed to visit URL');
      }
    }

    return results;
  }
}