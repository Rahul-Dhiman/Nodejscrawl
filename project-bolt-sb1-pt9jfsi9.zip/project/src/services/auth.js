import * as cheerio from 'cheerio';
import got from 'got';
import { CookieJar } from 'tough-cookie';
import { createLogger } from '../utils/log.js';

export default class AuthService {
  constructor() {
    this.logger = createLogger('auth');
    this.cookieJar = new CookieJar();
    this.auth = null;
  }

  async authenticate(loginConfig) {
    try {
      this.logger.info({ type: loginConfig.type }, 'Authenticating');

      switch (loginConfig.type) {
        case 'form':
          await this.formLogin(loginConfig.form);
          break;
        case 'bearer':
          this.bearerAuth(loginConfig.bearer);
          break;
        case 'basic':
          this.basicAuth(loginConfig.basic);
          break;
        case 'cookie':
          await this.cookieAuth(loginConfig.cookie);
          break;
        default:
          throw new Error(`Unsupported auth type: ${loginConfig.type}`);
      }

      this.logger.info('Authentication successful');
    } catch (error) {
      this.logger.error({ error }, 'Authentication failed');
      throw error;
    }
  }

  async formLogin(formConfig) {
    const {
      loginUrl,
      username,
      password,
      usernameField = 'username',
      passwordField = 'password',
      csrf = null
    } = formConfig;

    // Get login page first
    const loginPageResponse = await got(loginUrl, {
      cookieJar: this.cookieJar,
      headers: {
        'User-Agent': process.env.USER_AGENT || 'MyCrawler/1.0'
      }
    });

    const $ = cheerio.load(loginPageResponse.body);
    const formData = {};

    // Add username and password
    formData[usernameField] = username;
    formData[passwordField] = password;

    // Handle CSRF token
    if (csrf && csrf.tokenFrom === 'selector' && csrf.selector) {
      const csrfToken = $(csrf.selector).attr('value') || $(csrf.selector).text();
      if (csrfToken) {
        const csrfFieldName = $(csrf.selector).attr('name') || '_csrf_token';
        formData[csrfFieldName] = csrfToken;
      }
    }

    // Extract other hidden form fields
    $('input[type="hidden"]').each((_, el) => {
      const name = $(el).attr('name');
      const value = $(el).attr('value');
      if (name && !formData[name]) {
        formData[name] = value || '';
      }
    });

    // Submit login form
    const loginResponse = await got.post(loginUrl, {
      form: formData,
      cookieJar: this.cookieJar,
      followRedirect: false,
      headers: {
        'User-Agent': process.env.USER_AGENT || 'MyCrawler/1.0',
        'Referer': loginUrl
      }
    });

    // Check if login was successful (usually by checking for redirect or specific content)
    if (loginResponse.statusCode === 302 || loginResponse.statusCode === 200) {
      this.auth = {
        type: 'form',
        cookieJar: this.cookieJar
      };
    } else {
      throw new Error('Form login failed');
    }
  }

  bearerAuth(bearerConfig) {
    this.auth = {
      type: 'bearer',
      token: bearerConfig.token
    };
  }

  basicAuth(basicConfig) {
    this.auth = {
      type: 'basic',
      username: basicConfig.username,
      password: basicConfig.password
    };
  }

  async cookieAuth(cookieConfig) {
    // Set cookies directly
    for (const cookie of cookieConfig.cookies || []) {
      await this.cookieJar.setCookie(cookie, cookieConfig.domain || 'https://example.com');
    }

    this.auth = {
      type: 'cookie',
      cookieJar: this.cookieJar
    };
  }

  getAuth() {
    return this.auth;
  }

  // Re-authenticate on 401 errors
  async handleAuthError(response, originalConfig) {
    if (response.statusCode === 401 && originalConfig) {
      this.logger.info('Received 401, attempting re-authentication');
      await this.authenticate(originalConfig);
      return true;
    }
    return false;
  }
}