import fs from 'fs/promises';
import path from 'path';
import { createLogger } from '../utils/log.js';
import { generateHash } from '../utils/hash.js';

export default class DedupeService {
  constructor() {
    this.logger = createLogger('dedupe');
  }

  async deduplicateRun(runId, batchSize = 1000) {
    try {
      const inputPath = path.join('data', `run-${runId}.ndjson`);
      const outputPath = path.join('data', `run-${runId}-deduped.ndjson`);
      
      // Check if input file exists
      try {
        await fs.access(inputPath);
      } catch {
        throw new Error('Run file not found');
      }

      this.logger.info({ runId, batchSize }, 'Starting deduplication');

      const seenHashes = new Set();
      const commonParagraphs = new Map();
      let totalProcessed = 0;
      let duplicatesRemoved = 0;
      let boilerplateRemoved = 0;

      // Read file line by line
      const content = await fs.readFile(inputPath, 'utf8');
      const lines = content.trim().split('\n');
      const results = [];

      // First pass: collect paragraph frequency
      for (const line of lines) {
        if (!line.trim()) continue;
        
        try {
          const record = JSON.parse(line);
          if (record.text) {
            const paragraphs = this.extractParagraphs(record.text);
            for (const para of paragraphs) {
              if (para.length > 50) { // Only track substantial paragraphs
                const hash = generateHash(para);
                commonParagraphs.set(hash, (commonParagraphs.get(hash) || 0) + 1);
              }
            }
          }
        } catch (error) {
          this.logger.warn({ error }, 'Failed to parse line during first pass');
        }
      }

      // Identify boilerplate (paragraphs appearing in many documents)
      const threshold = Math.max(3, Math.floor(lines.length * 0.1)); // At least 3 or 10% of documents
      const boilerplateHashes = new Set();
      
      for (const [hash, count] of commonParagraphs.entries()) {
        if (count >= threshold) {
          boilerplateHashes.add(hash);
        }
      }

      this.logger.info({ 
        boilerplatePatterns: boilerplateHashes.size,
        threshold 
      }, 'Identified boilerplate patterns');

      // Second pass: deduplicate and remove boilerplate
      for (const line of lines) {
        if (!line.trim()) continue;
        
        try {
          const record = JSON.parse(line);
          totalProcessed++;

          // Check for exact duplicate by content hash
          if (seenHashes.has(record.sha1)) {
            duplicatesRemoved++;
            continue;
          }

          seenHashes.add(record.sha1);

          // Remove boilerplate
          if (record.text && boilerplateHashes.size > 0) {
            const originalText = record.text;
            record.text = this.removeBoilerplate(record.text, boilerplateHashes);
            
            if (record.text.length < originalText.length * 0.5) {
              boilerplateRemoved++;
              continue; // Skip if too much content was removed
            }

            // Update hash and word count
            record.sha1 = generateHash(record.text);
            record.wordCount = record.text.split(/\s+/).length;
            record.charCount = record.text.length;
          }

          results.push(record);
        } catch (error) {
          this.logger.warn({ error }, 'Failed to process line during deduplication');
        }
      }

      // Write deduplicated results
      const output = results.map(record => JSON.stringify(record)).join('\n');
      await fs.writeFile(outputPath, output);

      const stats = {
        totalProcessed,
        duplicatesRemoved,
        boilerplateRemoved,
        finalCount: results.length,
        reductionRatio: ((totalProcessed - results.length) / totalProcessed * 100).toFixed(2) + '%'
      };

      this.logger.info(stats, 'Deduplication completed');
      return stats;
    } catch (error) {
      this.logger.error({ error }, 'Deduplication failed');
      throw error;
    }
  }

  extractParagraphs(text) {
    return text
      .split('\n')
      .map(p => p.trim())
      .filter(p => p.length > 20);
  }

  removeBoilerplate(text, boilerplateHashes) {
    const paragraphs = this.extractParagraphs(text);
    const filteredParagraphs = [];

    for (const para of paragraphs) {
      const hash = generateHash(para);
      if (!boilerplateHashes.has(hash)) {
        filteredParagraphs.push(para);
      }
    }

    return filteredParagraphs.join('\n');
  }

  // Remove duplicates within a batch
  async deduplicateBatch(records) {
    const seen = new Set();
    const deduplicated = [];

    for (const record of records) {
      if (!seen.has(record.sha1)) {
        seen.add(record.sha1);
        deduplicated.push(record);
      }
    }

    return deduplicated;
  }
}