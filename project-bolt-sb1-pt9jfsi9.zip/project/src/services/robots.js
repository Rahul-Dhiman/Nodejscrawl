import got from 'got';
import robotsParser from 'robots-txt-parse';
import { createLogger } from '../utils/log.js';

export default class RobotsService {
  constructor() {
    this.logger = createLogger('robots');
    this.cache = new Map();
  }

  async canCrawl(url, userAgent = '*') {
    try {
      const urlObj = new URL(url);
      const robotsUrl = `${urlObj.protocol}//${urlObj.host}/robots.txt`;
      
      // Check cache first
      if (this.cache.has(robotsUrl)) {
        const robots = this.cache.get(robotsUrl);
        return this.checkRobots(robots, url, userAgent);
      }

      // Fetch robots.txt
      try {
        const response = await got(robotsUrl, {
          timeout: { request: 5000 },
          headers: {
            'User-Agent': userAgent
          }
        });

        const robots = robotsParser(response.body);
        this.cache.set(robotsUrl, robots);
        
        return this.checkRobots(robots, url, userAgent);
      } catch (error) {
        // If robots.txt doesn't exist or can't be fetched, allow crawling
        if (error.response?.statusCode === 404) {
          this.cache.set(robotsUrl, null);
          return true;
        }
        
        this.logger.warn({ error, robotsUrl }, 'Failed to fetch robots.txt');
        return true; // Default to allowing if we can't determine
      }
    } catch (error) {
      this.logger.error({ error, url }, 'Error checking robots.txt');
      return true; // Default to allowing
    }
  }

  checkRobots(robots, url, userAgent) {
    if (!robots) {
      return true; // No robots.txt
    }

    try {
      const urlPath = new URL(url).pathname;
      
      // Check if the path is allowed for the user agent
      const isAllowed = robots.isAllowed(urlPath, userAgent);
      
      if (!isAllowed) {
        this.logger.debug({ url, userAgent }, 'URL blocked by robots.txt');
      }
      
      return isAllowed;
    } catch (error) {
      this.logger.error({ error, url }, 'Error parsing robots.txt rules');
      return true; // Default to allowing
    }
  }

  getCrawlDelay(robotsUrl, userAgent = '*') {
    const robots = this.cache.get(robotsUrl);
    if (!robots) {
      return 0;
    }

    try {
      const delay = robots.getCrawlDelay(userAgent);
      return delay ? delay * 1000 : 0; // Convert to milliseconds
    } catch {
      return 0;
    }
  }

  clearCache() {
    this.cache.clear();
  }
}