import * as cheerio from 'cheerio';
import got from 'got';
import { CookieJar } from 'tough-cookie';
import iconv from 'iconv-lite';
import { createLogger } from '../utils/log.js';
import { generateHash } from '../utils/hash.js';
import { detectFramework, extractSpaData } from '../utils/frameworks.js';

let playwright;
try {
  playwright = await import('playwright');
} catch {
  // Playwright is optional
}

export default class ExtractService {
  constructor() {
    this.logger = createLogger('extract');
    this.cookieJar = new CookieJar();
    this.browser = null;
  }

  async extract(url, options = {}) {
    const {
      engine = 'http',
      onlyBodyText = true,
      spa = {},
      auth = null,
      retries = parseInt(process.env.RETRIES) || 3
    } = options;

    let lastError;
    
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        this.logger.debug({ url, attempt }, 'Extracting content');

        let result;
        if (engine === 'renderer' && playwright) {
          result = await this.extractWithRenderer(url, options);
        } else {
          result = await this.extractWithHttp(url, options);
        }

        if (result) {
          // Add SPA data extraction
          if (spa.jsonDiscovery || spa.extractEmbeddedState) {
            const spaData = extractSpaData(result.html, url, spa);
            if (spaData && Object.keys(spaData).length > 0) {
              result.spaData = spaData;
            }
          }

          return result;
        }
      } catch (error) {
        lastError = error;
        this.logger.warn({ url, attempt, error: error.message }, 'Extraction attempt failed');
        
        if (attempt < retries) {
          await this.sleep(Math.pow(2, attempt) * 1000); // Exponential backoff
        }
      }
    }

    throw lastError || new Error('All extraction attempts failed');
  }

  async extractWithHttp(url, options) {
    const { auth, timeout = parseInt(process.env.TIMEOUT_MS) || 20000 } = options;

    const requestOptions = {
      url,
      timeout: { request: timeout },
      headers: {
        'User-Agent': process.env.USER_AGENT || 'MyCrawler/1.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      },
      cookieJar: this.cookieJar,
      followRedirect: true,
      maxRedirects: 5,
      responseType: 'buffer'
    };

    // Add authentication headers
    if (auth) {
      if (auth.type === 'bearer' && auth.token) {
        requestOptions.headers.Authorization = `Bearer ${auth.token}`;
      } else if (auth.type === 'basic' && auth.username && auth.password) {
        const credentials = Buffer.from(`${auth.username}:${auth.password}`).toString('base64');
        requestOptions.headers.Authorization = `Basic ${credentials}`;
      }
    }

    const response = await got(requestOptions);
    
    // Handle different encodings
    let html;
    const contentType = response.headers['content-type'] || '';
    const charset = this.extractCharset(contentType) || 'utf8';
    
    if (charset !== 'utf8') {
      html = iconv.decode(response.body, charset);
    } else {
      html = response.body.toString();
    }

    return this.processHtml(html, url, response);
  }

  async extractWithRenderer(url, options) {
    if (!playwright) {
      throw new Error('Playwright not available for renderer engine');
    }

    if (!this.browser) {
      this.browser = await playwright.chromium.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
    }

    const context = await this.browser.newContext({
      userAgent: process.env.USER_AGENT || 'MyCrawler/1.0',
      viewport: { width: 1280, height: 720 }
    });

    const page = await context.newPage();
    
    try {
      // Set authentication if needed
      const { auth } = options;
      if (auth && auth.cookies) {
        await context.addCookies(auth.cookies);
      }

      await page.goto(url, { 
        waitUntil: 'networkidle',
        timeout: parseInt(process.env.TIMEOUT_MS) || 20000
      });

      // Wait for SPA to load
      await page.waitForTimeout(2000);

      const html = await page.content();
      const title = await page.title();
      
      return this.processHtml(html, url, { 
        statusCode: 200, 
        headers: { 'content-type': 'text/html' },
        title 
      });
    } finally {
      await context.close();
    }
  }

  processHtml(html, url, response) {
    const $ = cheerio.load(html);
    
    // Remove unwanted elements
    $('script, style, nav, footer, .sidebar, .menu, .navigation, .ads, .advertisement').remove();
    
    // Extract text content
    const title = $('title').text().trim() || $('h1').first().text().trim();
    const description = $('meta[name="description"]').attr('content') || 
                      $('meta[property="og:description"]').attr('content') || '';
    
    let text = '';
    if (response.onlyBodyText !== false) {
      // Extract only body text
      text = $('body').text()
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim();
    } else {
      // Extract all visible text
      text = $.text()
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim();
    }

    // Detect language
    const lang = $('html').attr('lang') || 
                $('meta[http-equiv="content-language"]').attr('content') || 
                'en';

    // Framework detection
    const framework = detectFramework(html);

    const result = {
      url,
      status: response.statusCode || 200,
      title,
      description,
      text,
      html: html.length > 100000 ? html.substring(0, 100000) + '...' : html, // Limit HTML size
      lang: lang.split('-')[0], // Get primary language
      framework,
      contentType: response.headers['content-type'] || 'text/html',
      contentLength: html.length,
      sha1: generateHash(text),
      timestamp: new Date().toISOString(),
      wordCount: text.split(/\s+/).length,
      charCount: text.length
    };

    return result;
  }

  extractCharset(contentType) {
    const match = contentType.match(/charset=([^;]+)/i);
    return match ? match[1].toLowerCase() : null;
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async destroy() {
    if (this.browser) {
      await this.browser.close();
    }
  }
}