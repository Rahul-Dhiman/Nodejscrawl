import { XMLParser } from 'fast-xml-parser';
import { gunzipSync } from 'zlib';
import got from 'got';
import { createLogger } from '../utils/log.js';
import { isValidUrl, normalizeUrl } from '../utils/url.js';

export default class SitemapService {
  constructor() {
    this.logger = createLogger('sitemap');
    this.parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
      textNodeName: '#text',
      parseAttributeValue: true
    });
  }

  async extractUrls(sitemapUrl, maxUrls = 50000) {
    try {
      this.logger.info({ sitemapUrl }, 'Extracting URLs from sitemap');
      
      const urls = new Set();
      await this.processSitemap(sitemapUrl, urls, maxUrls);
      
      const result = Array.from(urls).slice(0, maxUrls);
      this.logger.info({ count: result.length }, 'Extracted URLs from sitemap');
      
      return result;
    } catch (error) {
      this.logger.error({ error, sitemapUrl }, 'Failed to extract URLs from sitemap');
      return [];
    }
  }

  async processSitemap(url, urls, maxUrls) {
    if (urls.size >= maxUrls) {
      return;
    }

    try {
      // Fetch sitemap content
      const response = await got(url, {
        timeout: { request: 30000 },
        headers: {
          'User-Agent': process.env.USER_AGENT || 'MyCrawler/1.0'
        }
      });

      let content = response.body;

      // Handle gzipped sitemaps
      if (url.endsWith('.gz') || response.headers['content-encoding'] === 'gzip') {
        content = gunzipSync(Buffer.from(content)).toString();
      }

      // Parse XML
      const parsed = this.parser.parse(content);

      // Handle sitemap index
      if (parsed.sitemapindex) {
        await this.processSitemapIndex(parsed.sitemapindex, urls, maxUrls);
      }
      // Handle regular sitemap
      else if (parsed.urlset) {
        this.processUrlset(parsed.urlset, urls, maxUrls);
      }
    } catch (error) {
      this.logger.error({ error, url }, 'Failed to process sitemap');
    }
  }

  async processSitemapIndex(sitemapindex, urls, maxUrls) {
    const sitemaps = Array.isArray(sitemapindex.sitemap) 
      ? sitemapindex.sitemap 
      : [sitemapindex.sitemap];

    for (const sitemap of sitemaps) {
      if (urls.size >= maxUrls) break;
      
      const sitemapUrl = sitemap.loc['#text'] || sitemap.loc;
      if (isValidUrl(sitemapUrl)) {
        await this.processSitemap(sitemapUrl, urls, maxUrls);
      }
    }
  }

  processUrlset(urlset, urls, maxUrls) {
    const urlEntries = Array.isArray(urlset.url) ? urlset.url : [urlset.url];

    for (const urlEntry of urlEntries) {
      if (urls.size >= maxUrls) break;
      
      const loc = urlEntry.loc;
      const url = typeof loc === 'string' ? loc : loc['#text'];
      
      if (url && isValidUrl(url)) {
        urls.add(normalizeUrl(url));
      }
    }
  }
}