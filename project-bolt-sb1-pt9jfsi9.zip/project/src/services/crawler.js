import { EventEmitter } from 'events';
import fs from 'fs/promises';
import path from 'path';
import PQueue from 'p-queue';
import { v4 as uuidv4 } from 'uuid';
import SitemapService from './sitemap.js';
import SpiderService from './spider.js';
import ExtractService from './extract.js';
import AuthService from './auth.js';
import DedupeService from './dedupe.js';
import RobotsService from './robots.js';
import { createLogger } from '../utils/log.js';
import { isValidUrl, normalizeUrl, isSameHost } from '../utils/url.js';
import { createNdjsonWriter } from '../utils/stream.js';
import { sleep } from '../utils/frameworks.js';

export default class CrawlerService extends EventEmitter {
  constructor(config) {
    super();
    this.config = config;
    this.logger = createLogger('crawler');
    this.stats = {
      runId: config.runId,
      status: 'initializing',
      startTime: new Date().toISOString(),
      endTime: null,
      totalPages: 0,
      processedPages: 0,
      failedPages: 0,
      queuedPages: 0,
      duplicatePages: 0,
      bytesProcessed: 0,
      currentUrl: null,
      errors: []
    };

    this.queue = new PQueue({
      concurrency: parseInt(process.env.MAX_CONCURRENCY) || 8,
      interval: parseInt(process.env.PER_HOST_DELAY_MS) || 500,
      intervalCap: 1
    });

    this.hostQueues = new Map();
    this.visited = new Set();
    this.failed = new Set();
    this.robots = new Map();
    this.sessions = new Map();
    this.writer = null;
    this.checkpointInterval = null;
    this.running = false;

    // Services
    this.sitemapService = new SitemapService();
    this.spiderService = new SpiderService();
    this.extractService = new ExtractService();
    this.authService = new AuthService();
    this.dedupeService = new DedupeService();
    this.robotsService = new RobotsService();
  }

  async start() {
    try {
      this.running = true;
      this.stats.status = 'running';
      
      this.logger.info({ runId: this.config.runId }, 'Starting crawler');

      // Initialize output writer
      const outputPath = path.join('data', `run-${this.config.runId}.ndjson`);
      this.writer = createNdjsonWriter(outputPath);

      // Resume from checkpoint if specified
      if (this.config.resumeRunId) {
        await this.resumeFromCheckpoint();
      }

      // Get initial URLs
      let urls = [];
      
      if (this.config.mode === 'sitemap' || (this.config.mode === 'auto' && this.config.sitemapUrl)) {
        this.logger.info('Fetching sitemap URLs');
        urls = await this.sitemapService.extractUrls(this.config.sitemapUrl);
      }
      
      if (urls.length === 0 || this.config.mode === 'spider') {
        urls = this.config.seeds || [];
      }

      // Filter and normalize URLs
      urls = urls
        .filter(url => isValidUrl(url))
        .map(url => normalizeUrl(url))
        .filter(url => this.shouldCrawlUrl(url));

      this.stats.totalPages = Math.min(urls.length, this.config.maxPages);
      this.logger.info({ totalUrls: urls.length }, 'Starting crawl with URLs');

      // Setup authentication if needed
      if (this.config.login) {
        await this.authService.authenticate(this.config.login);
      }

      // Start checkpoint saving
      this.startCheckpointSaving();

      // Add URLs to queue
      for (const url of urls.slice(0, this.config.maxPages)) {
        this.addUrlToQueue(url);
      }

      // Wait for all processing to complete
      await this.queue.onIdle();
      
      await this.finish();
    } catch (error) {
      this.logger.error({ error }, 'Crawler failed');
      this.stats.status = 'failed';
      this.stats.errors.push(error.message);
      throw error;
    }
  }

  async stop() {
    this.running = false;
    this.stats.status = 'stopping';
    
    this.logger.info('Stopping crawler gracefully');
    
    // Clear the queue
    this.queue.clear();
    
    // Wait for current tasks to complete
    await this.queue.onIdle();
    
    await this.finish();
  }

  async finish() {
    this.stats.status = this.stats.status === 'stopping' ? 'stopped' : 'completed';
    this.stats.endTime = new Date().toISOString();
    
    // Stop checkpoint saving
    if (this.checkpointInterval) {
      clearInterval(this.checkpointInterval);
    }

    // Close writer
    if (this.writer) {
      await this.writer.end();
    }

    // Save final stats
    const statsPath = path.join('data', `run-${this.config.runId}-stats.json`);
    await fs.writeFile(statsPath, JSON.stringify(this.stats, null, 2));

    // Run deduplication if configured
    if (this.config.batchSizeForDedupe > 0) {
      this.logger.info('Running final deduplication');
      await this.dedupeService.deduplicateRun(this.config.runId, this.config.batchSizeForDedupe);
    }

    this.logger.info({ stats: this.stats }, 'Crawler finished');
    this.emit('finished', this.stats);
  }

  addUrlToQueue(url, depth = 0) {
    if (!this.running || this.visited.has(url) || this.failed.has(url)) {
      return;
    }

    const hostname = new URL(url).hostname;
    
    if (!this.hostQueues.has(hostname)) {
      this.hostQueues.set(hostname, new PQueue({
        concurrency: parseInt(process.env.PER_HOST_CONCURRENCY) || 2,
        interval: parseInt(process.env.PER_HOST_DELAY_MS) || 500,
        intervalCap: 1
      }));
    }

    const hostQueue = this.hostQueues.get(hostname);
    this.stats.queuedPages++;

    hostQueue.add(() => this.processUrl(url, depth));
  }

  async processUrl(url, depth = 0) {
    if (!this.running || this.visited.has(url)) {
      return;
    }

    this.visited.add(url);
    this.stats.currentUrl = url;
    this.stats.queuedPages--;

    try {
      // Check robots.txt
      if (process.env.RESPECT_ROBOTS === 'true') {
        const canCrawl = await this.robotsService.canCrawl(url, process.env.USER_AGENT);
        if (!canCrawl) {
          this.logger.debug({ url }, 'Blocked by robots.txt');
          return;
        }
      }

      // Extract content
      const result = await this.extractService.extract(url, {
        engine: this.config.engine,
        onlyBodyText: this.config.onlyBodyText,
        spa: this.config.spa,
        auth: this.authService.getAuth()
      });

      if (result) {
        // Write to output
        await this.writer.write(result);
        this.stats.processedPages++;
        this.stats.bytesProcessed += JSON.stringify(result).length;

        // Extract links for spider mode
        if (this.config.mode === 'spider' && depth < 3 && this.stats.processedPages < this.config.maxPages) {
          const links = this.spiderService.extractLinks(result.html, url);
          for (const link of links.slice(0, 10)) { // Limit links per page
            if (this.shouldCrawlUrl(link)) {
              this.addUrlToQueue(link, depth + 1);
            }
          }
        }
      }
    } catch (error) {
      this.logger.error({ url, error: error.message }, 'Failed to process URL');
      this.failed.add(url);
      this.stats.failedPages++;
      this.stats.errors.push(`${url}: ${error.message}`);
    }
  }

  shouldCrawlUrl(url) {
    try {
      // Same host check
      if (this.config.sameHost && this.config.seeds?.length > 0) {
        const seedHost = new URL(this.config.seeds[0]).hostname;
        if (!isSameHost(url, seedHost)) {
          return false;
        }
      }

      // Include patterns
      if (this.config.include?.length > 0) {
        const included = this.config.include.some(pattern => 
          new RegExp(pattern).test(url)
        );
        if (!included) return false;
      }

      // Exclude patterns
      if (this.config.exclude?.length > 0) {
        const excluded = this.config.exclude.some(pattern => 
          new RegExp(pattern).test(url)
        );
        if (excluded) return false;
      }

      return true;
    } catch {
      return false;
    }
  }

  startCheckpointSaving() {
    this.checkpointInterval = setInterval(async () => {
      await this.saveCheckpoint();
    }, 30000); // Save every 30 seconds
  }

  async saveCheckpoint() {
    try {
      const checkpoint = {
        runId: this.config.runId,
        config: this.config,
        stats: this.stats,
        visited: Array.from(this.visited),
        failed: Array.from(this.failed),
        timestamp: new Date().toISOString()
      };

      const checkpointPath = path.join('data', `run-${this.config.runId}-checkpoint.jsonl`);
      await fs.writeFile(checkpointPath, JSON.stringify(checkpoint));
    } catch (error) {
      this.logger.error({ error }, 'Failed to save checkpoint');
    }
  }

  async resumeFromCheckpoint() {
    try {
      const checkpointPath = path.join('data', `run-${this.config.resumeRunId}-checkpoint.jsonl`);
      const checkpointData = await fs.readFile(checkpointPath, 'utf8');
      const checkpoint = JSON.parse(checkpointData);

      this.visited = new Set(checkpoint.visited);
      this.failed = new Set(checkpoint.failed);
      this.stats = { ...this.stats, ...checkpoint.stats };
      this.stats.runId = this.config.runId; // Use new run ID

      this.logger.info({ 
        resumeRunId: this.config.resumeRunId,
        visitedCount: this.visited.size 
      }, 'Resumed from checkpoint');
    } catch (error) {
      this.logger.warn({ error }, 'Failed to resume from checkpoint, starting fresh');
    }
  }

  getStatus() {
    return {
      ...this.stats,
      queueSize: this.queue.size + this.queue.pending
    };
  }
}